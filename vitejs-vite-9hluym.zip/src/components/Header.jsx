import Navbar from './Navbar'

function Header(){
return (
  <section className="header-section section-padding">
    <div className="container">

    <Navbar/>

      <div className="row header-content" id="header">
          <div className="col-2-of-3">
              <div className="text-section">
                  <h1 className="h1 mb-md">Oi, Eu sou David, Estudante
                        <span className="hlight">Eng Software</span>
                  </h1>
                  <p className="p header-p mb-bg">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur euismod sem eget hendrerit lacinia. Etiam at tempor purus, at rhoncus elit. Vivamus scelerisque efficitur convallis. Integer sit amet arcu in magna commodo tempus. Integer magna nibh, posuere.
                  </p>
                  
                  <a className="btn" href="#my-works">
                      see my work
                  </a>
              </div>
          </div>
          <div className="col-1-of-3">
              <img src="img/K-On.png" alt="Open to work" className="header-img"/>
          </div>
      </div>
  </div>
  </section>

);
}

export default Header