import Tags from './Tags'

function Project(props){
  return(
    <div className="row align-center">
    <div className="col-1-of-2 pd-bg">
        <h3 className="h3">Latest Work</h3>
        <h2 className="h2">{props.title}</h2>
        <div className="tag-section">


        </div>
        <p className="p mb-bg">{props.content}</p>
        <a className="btn" href="#">
            see this project
        </a>
    </div>

    <div classNameName="col-1-of-2 pd-bg">
        <img src="img/chat-app.jpg" alt="chat-app" className="project-img"/>
    </div>
</div>
  )
}

export default Project 