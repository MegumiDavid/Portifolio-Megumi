function MySkillSection(){
  return(
    <section className="my-skills-section section-padding" id="my-skills">
    <div className="container">
      <div className="row align-top">
        <div className="col-1-of-2">
          <h1 className="h1 mb-md">
            My <span className="hlight">Skills</span>
          </h1>
        </div>
        <div className="col-1-of-2">
          <div className="skills-text-wrap">
            <h2 className="h2">Design</h2>
            <p className="p mb-bg">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Curabitur euismod sem eget hendrerit lacinia. Etiam at tempor
              purus, at rhoncus elit. Vivamus scelerisque efficitur convallis.
              Integer sit amet arcu in magna commodo tempus. Integer magna
              nibh, posuere.
            </p>
            <h2 className="h2">Development</h2>
            <p className="p">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Curabitur euismod sem eget hendrerit lacinia. Etiam at tempor
              purus, at rhoncus elit. Vivamus scelerisque efficitur convallis.
              Integer sit amet arcu in magna commodo tempus. Integer magna
              nibh, posuere.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
  )
}

export default MySkillSection