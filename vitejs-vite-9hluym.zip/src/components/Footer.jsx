function Footer() {

  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-row row justify-center">
          <a href="mailto:dvdshinjo@gmail.com" className="social-icon">
            <div className="circle">
              <i className="icon fa-solid fa-envelope"></i>
            </div>
          </a>

          <a
            href="https://www.linkedin.com/in/david-shinjo/"
            className="social-icon"
          >
            <div className="circle">
              <i className="icon fa-brands fa-linkedin-in"></i>
            </div>
          </a>

          <a href="https://github.com/MegumiDavid" className="social-icon">
            <div className="circle">
              <i className="icon fa-brands fa-github"></i>
            </div>
          </a>
        </div>
        © MegumiDavid - {currentYear}
      </div>
    </footer>
  );
}

export default Footer;