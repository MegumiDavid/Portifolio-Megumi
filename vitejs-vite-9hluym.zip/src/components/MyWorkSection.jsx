import Project from './Project'
import projectsList from "../projectsList"

function MyWorkSection(){
  return(
    <section className="my-works-section section-padding" id="my-works">
<div className="container">

{projectsList.map(project => (
        <Project
          key={project.key}
          title={project.title}
          content={project.content}
        />
  ))}
   
</div>

</section>
  )
}

export default MyWorkSection