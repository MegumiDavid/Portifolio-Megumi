function Navbar(){
  return(
    <div className="nav">
    <input type="checkbox" id="nav-check"/>
    <div className="nav-header">
      <div className="nav-title">
        <div className="logo">MegumiDavid.</div>
      </div>
    </div>
    <div className="nav-btn">
      <label for="nav-check">
        <span/>
        <span/>
        <span/>
      </label>
    </div>
    
    <div className="nav-links">
      <a className="nav-link hlight" href="#my-works" >my work</a>
      <a className="nav-link hlight" href="#my-skills">my skills</a>
    </div>
  </div>
  )
}

export default Navbar