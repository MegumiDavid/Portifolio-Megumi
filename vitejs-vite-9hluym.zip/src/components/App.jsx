import { useState } from 'react'
import '../App.css'
import Header from './Header'
import MySkillSection from './MySkillSection'
import MyWorkSection from './MyWorkSection'
import Footer from './Footer'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div>
      <Header/>
      <MyWorkSection />
      <MySkillSection />
      <Footer />
    </div>
  )
}

export default App
