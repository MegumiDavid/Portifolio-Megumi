const projects = [
  {
    key: 1,
    title: "Chat App Website",
    content:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Reiciendis consectetur provident vel autem, minus voluptatibus!",
      img:"../img/chatapp.png"
    },
    {
      key: 2,
      title: "Chat App Website",
      content:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Reiciendis consectetur provident vel autem, minus voluptatibus!",
      img:"../img/chatapp.png"
    },
    {
      key: 3,
      title: "Arrays",
      content:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Reiciendis consectetur provident vel autem, minus voluptatibus!",
      img:"../img/chatapp.png"
  },
]

export default projects;
